cd /Users/gonzaloaranda/Desktop/Servidor_2015 

java -cp jade.jar:Servidor_2015.jar:Monitor_2015.jar:. jade.Boot -agents entorno3213:agente.Entorno\(-map,mapa2.txt,-time,500\)
